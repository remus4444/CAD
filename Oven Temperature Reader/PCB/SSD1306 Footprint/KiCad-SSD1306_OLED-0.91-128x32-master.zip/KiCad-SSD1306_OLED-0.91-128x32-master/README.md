# KiCad-SSD1306_OLED-0.91-128x32

These are the KiCad files I create for the I2C SSD1306 0.91" 128x32 OLED display i used in my [Electrocard](http://michaelteeuw.nl/tagged/electrocard). I included a step file which can be used in a 3D rendering.

The absolute cumbersome and awful way of KiCad to manage libraries probably results in a wrongly setup directory or file structure for this KiCad part. Feel free to send a PR if it turns out it needs a different structure.